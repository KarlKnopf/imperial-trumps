---
layout: default
title: Home
---

# Welcome to the Intergalactic Newsletter

This is the future home of cosmic content! Check back soon.
